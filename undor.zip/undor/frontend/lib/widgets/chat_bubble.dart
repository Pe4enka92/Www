import 'package:flutter/material.dart';
import 'reaction_bar.dart';

class ChatBubble extends StatefulWidget {
  final String user;
  final String text;

  ChatBubble({required this.user, required this.text});

  @override
  State<ChatBubble> createState() => _ChatBubbleState();
}

class _ChatBubbleState extends State<ChatBubble> {
  List<String> reactions = [];

  void addReaction(String emoji) {
    setState(() {
      reactions.add(emoji);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 4),
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.blueGrey[700],
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.user, style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 4),
            Text(widget.text),
            ReactionBar(reactions: reactions, onAdd: addReaction),
          ],
        ),
      ),
    );
  }
}