import 'package:flutter/material.dart';
import 'emoji_picker.dart';

class ReactionBar extends StatelessWidget {
  final List<String> reactions;
  final Function(String) onAdd;

  ReactionBar({required this.reactions, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ...reactions.map((e) => Text(e, style: TextStyle(fontSize: 18))),
        IconButton(
          icon: Icon(Icons.emoji_emotions),
          onPressed: () async {
            String? emoji = await showDialog(
              context: context,
              builder: (_) => EmojiPicker(),
            );
            if (emoji != null) onAdd(emoji);
          },
        ),
      ],
    );
  }
}