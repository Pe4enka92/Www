import 'package:flutter/material.dart';

class EmojiPicker extends StatelessWidget {
  final List<String> emojis = ['😀','😂','😍','🤔','👍','❤️','🔥'];

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: GridView.count(
        crossAxisCount: 4,
        shrinkWrap: true,
        children: emojis.map((e) => TextButton(
          child: Text(e, style: TextStyle(fontSize: 24)),
          onPressed: () => Navigator.pop(context, e),
        )).toList(),
      ),
    );
  }
}