class Channel {
  String id;
  String name;
  List<String> subscribers;
  Map<String, String> roles;

  Channel({
    required this.id,
    required this.name,
    this.subscribers = const [],
    this.roles = const {},
  });
}