import 'package:flutter/material.dart';
import '../models/channel.dart';

class ChannelsScreen extends StatelessWidget {
  final List<Channel> channels = [
    Channel(id: '1', name: 'Новости', roles: {'user1': 'admin'}),
    Channel(id: '2', name: 'Игры'),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: channels.length,
      itemBuilder: (context, index) {
        final channel = channels[index];
        return ListTile(
          title: Text(channel.name),
          subtitle: Text('Подписчиков: ${channel.subscribers.length}'),
          trailing: Icon(Icons.campaign),
        );
      },
    );
  }
}