import 'package:flutter/material.dart';
import '../widgets/chat_bubble.dart';

class ChatsScreen extends StatelessWidget {
  final List<Map<String, String>> messages = [
    {"user": "Alice", "text": "Привет!"},
    {"user": "Bob", "text": "Привет, как дела?"},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.all(8),
      itemCount: messages.length,
      itemBuilder: (context, index) {
        final msg = messages[index];
        return ChatBubble(user: msg['user']!, text: msg['text']!);
      },
    );
  }
}