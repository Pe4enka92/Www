import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class VoiceChannelsScreen extends StatefulWidget {
  @override
  State<VoiceChannelsScreen> createState() => _VoiceChannelsScreenState();
}

class _VoiceChannelsScreenState extends State<VoiceChannelsScreen> {
  IO.Socket? socket;
  final _localRenderer = RTCVideoRenderer();

  @override
  void initState() {
    super.initState();
    initRenderers();
    connectSocket();
  }

  void initRenderers() async {
    await _localRenderer.initialize();
  }

  void connectSocket() {
    socket = IO.io('http://localhost:3000', <String, dynamic>{
      'transports': ['websocket'],
    });

    socket!.on('connect', (_) => print('Connected'));
    socket!.on('userJoined', (id) => print('User joined: $id'));
  }

  void joinRoom(String roomId) {
    socket!.emit('joinVoiceRoom', roomId);
  }

  @override
  void dispose() {
    _localRenderer.dispose();
    socket!.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Голосовые комнаты')),
      body: Center(
        child: ElevatedButton(
          onPressed: () => joinRoom('general'),
          child: Text('Присоединиться к комнате'),
        ),
      ),
    );
  }
}