import 'package:flutter/material.dart';

class BotScreen extends StatelessWidget {
  final List<String> logs = [];

  void runBotCommand(String input) {
    if (input.startsWith('/hello')) {
      logs.add('Bot: Привет, ${input.substring(7)}!');
    }
  }

  @override
  Widget build(BuildContext context) {
    TextEditingController controller = TextEditingController();

    return Column(
      children: [
        Expanded(
          child: ListView(
            children: logs.map((e) => Text(e)).toList(),
          ),
        ),
        Row(
          children: [
            Expanded(child: TextField(controller: controller)),
            IconButton(
              icon: Icon(Icons.send),
              onPressed: () {
                runBotCommand(controller.text);
                controller.clear();
              },
            ),
          ],
        )
      ],
    );
  }
}