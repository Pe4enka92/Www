import 'package:flutter/material.dart';
import 'screens/chats_screen.dart';
import 'screens/voice_channels_screen.dart';
import 'screens/channels_screen.dart';
import 'screens/bot_screen.dart';

void main() => runApp(UndorApp());

class UndorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Undor',
      theme: ThemeData.dark(),
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  final List<Widget> _screens = [
    ChatsScreen(),
    VoiceChannelsScreen(),
    ChannelsScreen(),
    BotScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Чаты'),
          BottomNavigationBarItem(icon: Icon(Icons.headset), label: 'Голос'),
          BottomNavigationBarItem(icon: Icon(Icons.campaign), label: 'Каналы'),
          BottomNavigationBarItem(icon: Icon(Icons.smart_toy), label: 'Боты'),
        ],
      ),
    );
  }
}