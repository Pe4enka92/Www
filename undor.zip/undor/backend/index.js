const express = require('express');
const mongoose = require('mongoose');
const http = require('http');
const socketIo = require('socket.io');
const messagesRouter = require('./routes/messages');
const channelsRouter = require('./routes/channels');
const botsRouter = require('./routes/bots');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" } });

app.use(express.json());
app.use('/api/messages', messagesRouter);
app.use('/api/channels', channelsRouter);
app.use('/api/bots', botsRouter);

// MongoDB
mongoose.connect('mongodb://localhost:27017/undor', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// WebRTC
require('./services/webrtc')(io);

server.listen(3000, () => console.log('Server running on port 3000'));
module.exports.io = io;