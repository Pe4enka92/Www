module.exports = (io) => {
  const peers = {};

  io.on('connection', (socket) => {
    socket.on('joinVoiceRoom', (roomId) => {
      if (!peers[roomId]) peers[roomId] = [];
      peers[roomId].push(socket.id);
      socket.join(roomId);
      socket.to(roomId).emit('userJoined', socket.id);
    });

    socket.on('sendOffer', ({ roomId, offer }) => {
      socket.to(roomId).emit('receiveOffer', { from: socket.id, offer });
    });

    socket.on('sendAnswer', ({ roomId, answer, to }) => {
      socket.to(to).emit('receiveAnswer', { from: socket.id, answer });
    });

    socket.on('iceCandidate', ({ roomId, candidate, to }) => {
      socket.to(to).emit('iceCandidate', { from: socket.id, candidate });
    });

    socket.on('leaveRoom', (roomId) => {
      peers[roomId] = peers[roomId].filter(id => id !== socket.id);
      socket.leave(roomId);
      socket.to(roomId).emit('userLeft', socket.id);
    });

    socket.on('disconnect', () => {
      for (const roomId in peers) {
        peers[roomId] = peers[roomId].filter(id => id !== socket.id);
      }
    });
  });
};