const express = require('express');
const router = express.Router();
const Message = require('../models/message');
const io = require('../index').io;

router.get('/:channelId', async (req, res) => {
  const messages = await Message.find({ channelId: req.params.channelId });
  res.json(messages);
});

router.post('/', async (req, res) => {
  const msg = new Message(req.body);
  await msg.save();
  io.emit('newMessage', msg);
  res.sendStatus(200);
});

module.exports = router;