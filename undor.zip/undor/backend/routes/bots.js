const express = require('express');
const router = express.Router();
const BotCommand = require('../models/bot_command');

router.get('/', async (req, res) => {
  const commands = await BotCommand.find();
  res.json(commands);
});

router.post('/', async (req, res) => {
  const command = new BotCommand(req.body);
  await command.save();
  res.sendStatus(200);
});

module.exports = router;