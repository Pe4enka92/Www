const express = require('express');
const router = express.Router();
const Channel = require('../models/channel');
const io = require('../index').io;

router.get('/', async (req, res) => {
  const channels = await Channel.find();
  res.json(channels);
});

router.post('/', async (req, res) => {
  const channel = new Channel(req.body);
  await channel.save();
  io.emit('newChannel', channel);
  res.sendStatus(200);
});

module.exports = router;