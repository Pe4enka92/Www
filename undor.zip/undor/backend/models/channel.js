const mongoose = require('mongoose');

const channelSchema = new mongoose.Schema({
  name: String,
  subscribers: [String],
  roles: Map,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Channel', channelSchema);