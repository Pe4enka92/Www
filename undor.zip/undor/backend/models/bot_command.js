const mongoose = require('mongoose');

const botCommandSchema = new mongoose.Schema({
  command: String,
  description: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('BotCommand', botCommandSchema);